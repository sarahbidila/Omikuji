package com.sarah.daikichi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichiAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichiAssignmentApplication.class, args);
	}

}
